# Pacote SQL da apresentação de Banco de Dados — 22/11/2026

Gerado do commit `6647d644eee117fda661c0d8609892df1be8d53d` da `main`, com as correções de
documentação de 22/11/2026 (ver "Documentação atualizada", abaixo).

Substitui o `pacote-sql-loja-gestao.zip` de 12/10/2026, que tinha 10 arquivos e parava no `06c`.

## O que o esquema produz

| Medida | Valor conferido em 22/11/2026 |
| --- | --- |
| PostgreSQL | 18.6 (contêiner `postgres:18`) |
| Migrações aplicadas | 20, de `V1` a **`V14`**, 0 falhas |
| Tabelas de aplicação | **21** (mais `flyway_schema_history`) |
| Views / funções / gatilhos / índices | 20 / 18 / 12 / 55 |
| Chaves estrangeiras | 36 |

Duas das 21 tabelas nascem vazias, e isso é esperado: `product_photo` (só ganha linha quando a
loja envia uma foto) e `product_price_history` (só ganha linha quando um preço muda).

## Estrutura

```
scripts/      os 15 scripts SQL e os 4 runners; olist/ tem a massa de demonstração
migracoes/    migration/ (V1 a V14) e demo/ (V6_2, V11_1, V11_2, V12_2)
roteiros/     roteiro da banca, guia de preparação, modelo ERP/PDV, dicionário e migrações
Dockerfile, docker-compose.demo.yml, docker-compose.test.yml
```

## Como rodar a prova de banco

As migrações usam `${flyway:defaultSchema}` e **só rodam pelo Flyway**, nunca por `psql` direto.
O caminho suportado é subir a stack e depois rodar os scripts.

```bash
export SBI_DEMO_PASSWORD='escolha-uma-senha-de-8-a-72'
export SBI_DB_PASSWORD="$(openssl rand -hex 16)"
docker compose -f docker-compose.demo.yml -p sbi-demo up --build --wait
```

Com a stack de pé, de dentro de `scripts/`:

```bash
CONTAINER=sbi-demo-db-1 DB=sbi_demo SUPERUSER=sbi bash run_bd.sh            # espera 61 PASS
CONTAINER=sbi-demo-db-1 DB=sbi_demo SUPERUSER=sbi bash run_olist_bd.sh      # espera 7 PASS sem a API
CONTAINER=sbi-demo-db-1 DB=sbi_demo SUPERUSER=sbi bash run_apresentacao.sh  # espera 17 PASS
```

O `run_apresentacao.sh` termina executando `11_prova_banco.sql`, que é a prova pedida pela banca:
versão e inventário, CRUD completo em transação terminada em `ROLLBACK`, cinco recusas de
integridade e as consultas analíticas com controle do grão do `JOIN`.

Para rodar só a prova:

```bash
docker cp . sbi-demo-db-1:/tmp/pacote-sql
docker exec -i sbi-demo-db-1 sh -c 'cd /tmp/pacote-sql && psql -X -U sbi -d sbi_demo -v ON_ERROR_STOP=1 -f 11_prova_banco.sql'
```

**Limitação deste pacote avulso:** a etapa opcional `CT-DEMO-05` do `run_olist_bd.sh` chama
`scripts/demo-olist-api.mjs` do repositório completo e não está aqui. Sem ela o runner espera
7 PASS em vez de 11, e o próprio script já trata os dois casos.

**Nunca** rode `07_carga_olist.sql` nem `10_carga_apresentacao.sql` contra o banco publicado no
Neon: eles gravam. A prova `11_prova_banco.sql` termina em `ROLLBACK`, mas rode-a no Docker local
mesmo assim.

## Senhas

Nenhuma senha vai neste pacote. `SBI_DB_PASSWORD` e `SBI_DEMO_PASSWORD` são escolhidas por quem
sobe a stack; sem a segunda, a migração `V6_1` falha na primeira conta e a API não sobe.

## Documentação atualizada em 22/11/2026

Os arquivos abaixo diferem do commit `6647d64` apenas por correções de números conferidos contra
a instância real:

- `scripts/README.md` — `run_bd.sh` roda sobre V1–V14 (dizia V1–V12)
- `roteiros/roteiro-banco-de-dados.md` — 21 tabelas e última migração `14` (dizia 20 e `12.2`)
- `roteiros/preparar-apresentacao.md` — 21 tabelas, 18 funções, 12 gatilhos, V1 a V14

## Dados

Seed sintético mais um recorte do conjunto público da Olist (CC BY-NC-SA 4.0), com pedidos
anonimizados e nomes e documentos sintéticos. Nenhuma pessoa real aparece. Veja
`scripts/olist/NOTICE.md`.
